#define _WINSOCK_DEPRECATED_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>

#define BUF_SIZE 30
#pragma comment(lib,"ws2_32.lib")
void ErrorHandling(char* message);

int main() {
	WSADATA wsaData;
	SOCKET sock;
	char message[BUF_SIZE];
	int strLen;
	SOCKADDR_IN servAdr;
	if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
		ErrorHandling("WSAStartup() error!");

	sock = socket(PF_INET, SOCK_DGRAM, 0);
	if (sock == INVALID_SOCKET)
		ErrorHandling("socket() error");

	memset(&servAdr, 0, sizeof(servAdr));
	servAdr.sin_family = AF_INET;
	servAdr.sin_addr.s_addr = inet_addr("10.30.3.13");
	servAdr.sin_port = htons(9900);
	puts("test", stdout);
	connect(sock, (SOCKADDR*)&servAdr, sizeof(servAdr));

	while (1) {
		fputs("Insert message(q to quit) : ", stdout);
		fgets(message, sizeof(message), stdin);
		if(!strcmp(message,"q\n")||!strcmp(message,"Q\n"))
			break;

			send(sock,message,strlen(message),0);
			message[strLen] = 0;
			printf("Message from server : %s\n", message);
	}
	closesocket(sock);
	WSACleanup();

	return 0;
}

void ErrorHandling(char* message) {
	fputs(message, stderr);
	fputc('\n', stderr);
	exit(1);
}